using static DraggableItem;
using System.Collections.Generic;

public class BasicItem : a_Item
{
    public BasicItem(Entity entity, List<ItemUpgrade> upgrades) : base(entity, upgrades)
    {
    }
}