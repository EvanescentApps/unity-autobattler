public static class SceneData
{
    public static int LevelInt = 0;
}
