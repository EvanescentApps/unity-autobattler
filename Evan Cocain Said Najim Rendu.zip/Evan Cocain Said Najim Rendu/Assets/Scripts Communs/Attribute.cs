// Abstract class for Champion Abilities
using UnityEngine;

public abstract class Attribute : MonoBehaviour
{
    public abstract void Upgrade(int level);
}
